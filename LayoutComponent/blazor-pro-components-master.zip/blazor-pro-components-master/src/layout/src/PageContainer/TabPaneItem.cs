namespace AntDesign.ProLayout
{
    public class TabPaneItem
    {
        public string Key { get; set; }
        public string Tab { get; set; }
    }
}